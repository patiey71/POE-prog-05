Put your screenshot of the green GitHub Actions run here as ci-green-build.png
